#modules requirements
import time
import os
import random
import math
import pygame
from os import listdir
from os.path import isfile,join

from pygame.sprite import Group

#initializing

pygame.init()

#window setup

icon=pygame.image.load("fall.png")

pygame.display.set_icon(icon)

pygame.display.set_caption("ONION SHAWL")

w,h=1000,800

fps=60

p_v=5

window=pygame.display.set_mode((w,h))

#player
def flip(sprites):
    return[pygame.transform.flip(sprite,True,False)for sprite in sprites]

def load_sprite_sheet(dir1,dir2,width,height,direction=False):
    path=join("assets",dir1,dir2)
    images=[f for f in listdir(path) if isfile(join(path,f))]
    all_sprites={}

    for image in images:
        sprite_sheet=pygame.image.load(join(path,image)).convert_alpha()
        sprites=[]
        for i in range(sprite_sheet.get_width()//width):
            surface=pygame.Surface((width,height),pygame.SRCALPHA,32)
            rect=pygame.Rect(i*width,0,width,height)
            surface.blit(sprite_sheet,(0,0),rect)
            sprites.append(pygame.transform.scale2x(surface))
        if direction:
            all_sprites[image.replace(".png","")+"right"]=sprites
            all_sprites[image.replace(".png","")+"left"] =flip(sprites)
        else:
            all_sprites[image.replace(".png","")]=sprites
    return all_sprites

def get_block(size):
    path=join("assets","Terrain","Terrain.png")
    image=pygame.image.load(path).convert_alpha()
    surface=pygame.Surface((size,size),pygame.SRCALPHA,32)
    rect=pygame.Rect(96,64,size,size)
    surface.blit(image,(0,0),rect)
    return pygame.transform.scale2x(surface)
class Player(pygame.sprite.Sprite):
    GRAVITY=1
    COLOR=(255,0,0)
    SPRITES=load_sprite_sheet("MainCharacters","MaskDude",32,32,True)
    DELAY=2
    def __init__(self,x,y,width,height):
        self.rect=pygame.Rect(x,y,width,height)
        self.x_vel=0
        self.y_vel=0
        self.mask=None
        self.direction="left"
        self.animation_count=0
        self.fall_count=0
        self.jump_count=0
        self.hit=False
        self.hitcount=0
        if self.jump_count==1:
            self.fall_count=0
    def jump(self):
        self.y_vel = -self.GRAVITY * 8
        self.animation_count = 0
        self.jump_count += 1
        if self.jump_count == 1:
            self.fall_count = 0
    def move(self,dx,dy):
        self.rect.x +=dx
        self.rect.y +=dy
    def make_hit(self):
        self.hit = True
        self.hitcount = 0  # Reset hit count
    def move_left(self,vel):
        self.x_vel = -vel
        if self.direction != "left":
            self.direction="left"
            self.animation_count= 0

    def move_right(self,vel):
        self.x_vel= vel
        if self.direction != "right":
            self.direction="right"
            self.animation_count= 0
    
    def update_sprite(self):
        sprite_sheet = "idle"
        if self.hit:
            sprite_sheet="hit"
        elif self.y_vel < 0:
            if self.jump_count == 1:
                sprite_sheet = "jump"
            elif self.jump_count == 2:
                sprite_sheet = "double_jump"
        elif self.y_vel > self.GRAVITY * 2:
            sprite_sheet = "fall"
        elif self.x_vel != 0:
            sprite_sheet = "run"

        sprite_sheet_name = sprite_sheet  + self.direction
        sprites = self.SPRITES[sprite_sheet_name]
        sprite_index = (self.animation_count //
                        self.DELAY) % len(sprites)
        self.sprite = sprites[sprite_index]
        self.animation_count += 1
        self.update()

    def update(self):
        self.rect=self.sprite.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask= pygame.mask.from_surface(self.sprite)
  
    def landed(self):
        self.fall_count =0
        self.y_vel = 0
        self.jump_count=0

    def hit_head(self):
        self.count = 0
        self.y_vel*=-1

    def loop(self,fps):
        self.y_vel+=min(1,(self.fall_count/fps)*self.GRAVITY)
        self.move(self.x_vel,self.y_vel)
        if self.hit:
            self.hitcount += 1
        if self.hitcount > fps * 2:
            self.hit = False
            self.hitcount = 0

        self.fall_count+=1
        self.update_sprite()

    def draw(self,win,offset_x):
        win.blit(self.sprite,(self.rect.x-offset_x,self.rect.y))

#delays

            
            
class object(pygame.sprite.Sprite):
    def __init__(self, x,y,width,height,name=None):
        super().__init__()
        self.rect=pygame.Rect(x,y,width,height)
        self.image=pygame.Surface((width,height),pygame.SRCALPHA)
        self.width=width
        self.height=height
        self.name=name

    def draw(self,win,offset_x):
        win.blit(self.image,(self.rect.x-offset_x,self.rect.y))

class Block(object):
    def __init__(self, x,y,size):
        super().__init__(x,y,size,size)
        block=get_block(size)
        self.image.blit(block,(0,0))
        self.mask=pygame.mask.from_surface(self.image)
class Saw(object):
    ANIMATION_DELAY = 1

    def __init__(self, x, y, width, height):
        super().__init__(x, y, width, height, "saw")
        self.rect=pygame.Rect(x,y,width,height)
        self.saw = load_sprite_sheet("Traps", "Saw", width, height)
        self.image = self.saw["off"][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = "off"
        self.x_vel = 2  # Initial velocity
        self.direction = 1  # 1 for right, -1 for left

    def on(self):
        self.animation_name = "on"

    def off(self):
        self.animation_name = "off"

    def move(self,x,x2):
        self.rect.x += self.x_vel * self.direction
        # Check if the saw has reached the boundaries and change direction if needed
        if self.rect.right >= x:
            self.direction = -1
        elif self.rect.left <= x2:
            self.direction = 1

    def loop(self):
        sprites = self.saw[self.animation_name]
        sprite_index = (self.animation_count //
                        self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1

        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)

        if self.animation_count // self.ANIMATION_DELAY > len(sprites):
            self.animation_count = 0

class Fruit():
    sprites=load_sprite_sheet("Items","Kiwi",32,32)
    delay = 1
    def __init__(self, x, y, width, height):
        self.rect=pygame.Rect(x,y,width,height)
        self.animation_count = 0
        self.hit=False

    def make_hit(self):
        self.hit = True

    def update_sprite(self):
        if self.hit:
            sprite_sheet="Collected"
        else:
            sprite_sheet = "kiwi"
        Sprites = self.sprites[sprite_sheet ]
        sprite_index = (self.animation_count // self.delay) % len(Sprites)
        self.sprite = Sprites[sprite_index]
        self.animation_count += 1

    def loop(self):
        self.update_sprite()
    def draw(self,win,offset_x):
        win.blit(self.sprite,(self.rect.x-offset_x,self.rect.y))     
        
#backround
class Fire(object):
    ANIMATION_DELAY=5
    def __init__(self, x, y, width, height):
        super().__init__(x, y, width, height, "fire")
        self.fire=load_sprite_sheet("Traps","fire",width,height)
        self.image=self.fire["off"][0]
        self.mask=pygame.mask.from_surface(self.image)
        self.animation_count=0
        self.animation_name=["off"]
    def on(self):
        self.animation_name = "on"

    def off(self):
        self.animation_name = "off"

    def loop(self):
        sprites = self.fire[self.animation_name]
        sprite_index = (self.animation_count //
                        self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1

        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)

        if self.animation_count // self.ANIMATION_DELAY > len(sprites):
            self.animation_count = 0
class Enemy(pygame.sprite.Sprite):
    COLOR = (255, 0 ,0)
    sprites=load_sprite_sheet("MainCharacters","VirtualGuy",32,32)
    delay=3
    lop=0
    def __init__(self, x,y,width,height):
        self.rect=pygame.Rect(x,y,width,height)
        self.mask=None
        self.direction="left"
        self.animation_count=0
      
    def update_sprite(self):
        if self.lop < 100:
            sprite_sheet = "Appearing (96x96)"
        else:
            sprite_sheet="idle"
        Sprites = self.sprites[sprite_sheet ]
        sprite_index = (self.animation_count // self.delay) % len(Sprites)
        self.sprite = Sprites[sprite_index]
        self.animation_count += 1
    def loop(self):
        self.lop+=1
        self.update_sprite()
    def draw(self,win,offset_x):
        win.blit(self.sprite,(self.rect.x-offset_x,self.rect.y))       
#backround
def get_background(name):
    image = pygame.image.load(join("assets", "Background", name))
    _, _, width, height = image.get_rect()
    tiles = []

    for i in range(w // width + 1):
        for j in range(h // height + 1):
            pos = (i * width, j * height)
            tiles.append(pos)

    return tiles, image

def draw(window,background, bg_image,player,objects,offset_x,enemy,KI,score,score2):
    font = pygame.font.Font('freesansbold.ttf', 32)
    score_display = font.render("x " + str(score), True, (255, 255, 255))
    score_display2 = font.render("x " + str(score2), True, (255, 255, 255))
    images=load_sprite_sheet("Items","Kiwi",32,32)
    image=images["kiwi"]
    image2=pygame.image.load("jump.png")
    ima_1=image[0]
    for tile in background:
        window.blit(bg_image, tile)

    for j in KI:
        for k in j:
            k.draw(window,offset_x)
    for obj in objects:
        obj.draw(window,offset_x)
    window.blit(image2,(800,80))
    window.blit(ima_1,(790,33))
    window.blit(score_display, (850, 50))
    window.blit(score_display2, (850, 80))
    player.draw(window,offset_x)
    enemy.draw(window,offset_x)
    pygame.display.update()



def handel_vertical_collision(player,objects,dy):
    collided_obj=[]
    for obj in objects:
        if pygame.sprite.collide_mask(player,obj):
            if dy>0:
                player.rect.bottom=obj.rect.top
                player.landed()
            elif dy<0:
                player.rect.top=obj.rect.bottom
                player.hit_head()
            collided_obj.append(obj)
    return collided_obj
def collide(player,objects,dx):
    player.move(dx,0)
    player.update()
    collided_object=None
    for obj in objects:
        if pygame.sprite.collide_mask(player,obj):
            collided_object = obj
            break
    player.move(-dx,0)
    player.update()
    return collided_object
def handel_move(player,objects,score2):

    key=pygame.key.get_pressed()
    player.x_vel = 0
    collide_left=collide(player,objects,-p_v*2)
    collide_right=collide(player,objects,p_v*2)
    if key[pygame.K_a]and not collide_left:
        player.move_left(p_v)
    if key[pygame.K_d] and not collide_right:
        player.move_right(p_v)

    vertical_collide =handel_vertical_collision(player, objects, player.y_vel)
    to_check = [collide_left, collide_right, *vertical_collide]

    for obj in to_check:
        if obj and obj.name == "fire" or  obj and obj.name == "saw":
            score2=score2-1
            player.make_hit()
    return score2
def enemy_s():
    a=[[200,255],[-280,255],[-180,643],[600,450]]
    b=a[random.randint(0,len(a)-1)]
    enemy=Enemy(b[0],b[1],50,50)
    return enemy
#score
def game_over():
    font = pygame.font.Font('freesansbold.ttf', 64)
    over_font=font.render("GAME OVER",True,(255,255,255))
    window.blit(over_font,(200,500))
def show_score(score,score2):
    font = pygame.font.Font('freesansbold.ttf', 32)
    score_display = font.render(f"Total Score :"+ str(score+score2), True, (255, 255, 255))
    window.blit(score_display, (200, 400))
def main(window):
    score = 0
    score2=0
    delay = 4000  
    delay_active = True
    delay_start_time = pygame.time.get_ticks()
    delay_counter = 0
    max_delay_loops = 2

    enemy=enemy_s()
    background, bg_image = get_background("Blue.png")
    t_score=0
    offset_x=0
    scroll_area=200
    clock=pygame.time.Clock()
    block_size=96
    saw,saw1=Saw(450,h-block_size-64,38,38),Saw(600,h-block_size*4-90,38,38)
    saw.on(),saw1.on()
    KI=[[(Fruit(120-i*64,h-block_size*3-32,32,32))for i in range(6)]+[(Fruit(120-i*64,h-block_size*4-32,32,32))for i in range(6)]+[(Fruit(120-i*64,h-block_size*5-32,32,32))for i in range(6)]+[(Fruit(380+i*64,h-block_size*6,32,32))for i in range(5)]+[(Fruit(380+i*64,h-block_size*5-32,32,32))for i in range(5)]+[(Fruit(380+i*64,h-block_size*4-64,32,32))for i in range(5)]+[(Fruit(380+i*64,h-block_size*3-97,32,32))for i in range(5)]]
    fire,fire2=Fire(32,h-block_size*3+32,16,32),Fire(-90,h-block_size*8+32,16,32)
    fire1=Fire(300,h-block_size*2+32,16,32)
    fire.on(),fire1.on(),fire2.on()
    floor=[Block(i*block_size,h-block_size,block_size)for i in range(-w//block_size,w*2//block_size)]
    run=True
    traps=[saw,fire,fire1,saw1,fire2]
    objects=[(Block(i*96,h-block_size*2,block_size))for i in range(3)]+[*floor]+[Block(-400+(1*96),h-block_size*5,block_size)]+[Block(500+(i*96),h-block_size*3,block_size)for i in range(4)]+[Block(-100+(i*96),h-block_size*7,block_size)for i in range(2)]+[Block(500+(i*96),h-block_size*7,block_size)for i in range(2)]+[Block(700+(i*96),h-block_size*5,block_size)for i in range(2)]+[Block(300-(i*96),h-block_size*5,block_size)for i in range(2)]+traps
    player=Player(200,300,50,50)
  
    while run:
        clock.tick(fps)
        for j in KI:
            for k in j:
                if pygame.sprite.collide_rect(k, player):
                    k.make_hit()
                    j.remove(k)
                    score+=1
        if pygame.sprite.collide_rect(enemy,player):
                score2+=1
                

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run=False
                break

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and player.jump_count <2 :
                    player.jump()
                    
        if delay_active:
            current_time = pygame.time.get_ticks()
            if current_time - delay_start_time >= delay:
                delay_counter += 1
                if delay_counter == max_delay_loops:
                    delay_active = False
                else:
                    enemy=enemy_s()
                    # Reset the delay start time
                    delay_start_time = current_time

        if ((player.rect.right - offset_x >= w - scroll_area) and player.x_vel > 0) or (
                (player.rect.left - offset_x <= scroll_area) and player.x_vel < 0):
            offset_x += player.x_vel
        for i in range(1):
            saw1.loop()
            saw1.move(700,400)
            saw.loop()
            saw.move(1100,300)        
        
        for j in KI:
            for k in j:
                k.loop()
        player.loop(fps)
        fire.loop(),fire2.loop(),fire1.loop()    
        score2=handel_move(player,objects,score2)
        enemy.loop()


  

        draw(window,background, bg_image,player,objects,offset_x,enemy,KI,score,score2)
        if delay_counter==max_delay_loops:
          # Game over logic
            game_over()
            show_score(score, score2)
            pygame.display.update()
            pygame.time.delay(5000)  # Pause for 5 seconds before quitting
            pygame.quit()
            quit()
        


if __name__ == "__main__":
    main(window)
