# Specify the limits and step size
start = 1
end = 10
step = 1

# Loop to simultaneously increase and decrease values
for i in range(start, end+1, step):
    increase_value = i
    decrease_value = end - i + 1
    print(f"Increase: {increase_value}, Decrease: {decrease_value}")